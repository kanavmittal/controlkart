Placeholder CAD files for MiBRX-6M
